package br.unipar.devbackend.cadastroaluno.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Endereco {

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;
   private String cep;
   private String logradouro;
   private String complemento;
   private String bairro;
   private String localidade;
   private String uf;

   @ManyToOne
   @JoinColumn(name = "aluno_id") //FK
   private Aluno aluno;

}
